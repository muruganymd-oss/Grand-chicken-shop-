package com.grandchickenshop;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.view.Gravity;
import android.widget.*;
import android.content.SharedPreferences;
import java.util.Locale;

public class MainActivity extends Activity {
    SharedPreferences db;
    LinearLayout root;
    EditText qty, price, expense;
    Spinner product;
    TextView total;
    boolean tamil=false;
    double sales=0, stock=100, expenses=0;
    String t(String en,String ta){ return tamil?ta:en; }
    int red=Color.rgb(177,20,25);
    public void onCreate(Bundle b){
        super.onCreate(b);
        db=getSharedPreferences("shop",0);
        sales=Double.longBitsToDouble(db.getLong("sales",Double.doubleToLongBits(0)));
        stock=Double.longBitsToDouble(db.getLong("stock",Double.doubleToLongBits(100)));
        expenses=Double.longBitsToDouble(db.getLong("expenses",Double.doubleToLongBits(0)));
        showHome();
    }
    TextView text(String s,int size){
        TextView v=new TextView(this); v.setText(s); v.setTextSize(size);
        v.setTextColor(Color.rgb(55,30,20)); v.setPadding(8,12,8,12); return v;
    }
    Button btn(String s){
        Button b=new Button(this); b.setText(s); b.setAllCaps(false);
        b.setTextColor(Color.WHITE);
        b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(red)); return b;
    }
    void base(String title){
        root=new LinearLayout(this); root.setOrientation(1); root.setPadding(18,12,18,18);
        root.setBackgroundColor(Color.rgb(255,250,230));
        ScrollView sc=new ScrollView(this); sc.addView(root); setContentView(sc);
        TextView h=text("🐓 GRAND CHICKEN SHOP\n"+title,24);
        h.setTextColor(red); h.setGravity(Gravity.CENTER); h.setTypeface(null,1); root.addView(h);
    }
    void showHome(){
        base(t("Shop Dashboard","கடை முகப்பு"));
        Button lang=btn("தமிழ் / English");
        lang.setOnClickListener(v->{tamil=!tamil;showHome();}); root.addView(lang);
        root.addView(text(t("Sales: ₹","விற்பனை: ₹")+fmt(sales)+"    "+t("Expenses: ₹","செலவு: ₹")+fmt(expenses),18));
        root.addView(text(t("Estimated stock: ","மீதமுள்ள இருப்பு: ")+fmt(stock)+" kg",18));
        Button bill=btn(t("New Bill / Sale","புதிய பில் / விற்பனை"));
        bill.setOnClickListener(v->showBilling()); root.addView(bill);
        Button exp=btn(t("Add Expense","செலவு சேர்க்க"));
        exp.setOnClickListener(v->showExpense()); root.addView(exp);
        Button report=btn(t("Daily Report","தினசரி அறிக்கை"));
        report.setOnClickListener(v->showReport()); root.addView(report);
        root.addView(text(t("Offline prototype. Data is saved on this phone.","ஆஃப்லைன் முன்மாதிரி. தரவு இந்த மொபைலில் சேமிக்கப்படும்."),14));
    }
    Button back(){Button b=btn(t("Back","பின்னால்"));b.setOnClickListener(v->showHome());return b;}
    String fmt(double x){return String.format(Locale.US,"%.2f",x);}
    void save(){
        db.edit().putLong("sales",Double.doubleToLongBits(sales))
        .putLong("stock",Double.doubleToLongBits(stock))
        .putLong("expenses",Double.doubleToLongBits(expenses)).apply();
    }
    void showBilling(){
        base(t("Create Bill","பில் உருவாக்கு"));
        product=new Spinner(this);
        product.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,
          new String[]{t("Whole Chicken","முழுக் கோழி"),t("Cut Chicken","வெட்டிய கோழி")}));
        root.addView(text(t("Product","பொருள்"),16)); root.addView(product);
        qty=new EditText(this);qty.setHint(t("Quantity (kg)","அளவு (கிலோ)"));qty.setInputType(8194);root.addView(qty);
        price=new EditText(this);price.setHint(t("Price per kg (₹)","ஒரு கிலோ விலை (₹)"));price.setInputType(8194);root.addView(price);
        total=text("",20);root.addView(total);
        Button calc=btn(t("Calculate & Save Sale","கணக்கிட்டு விற்பனையைச் சேமி"));
        calc.setOnClickListener(v->{try{
            double q=Double.parseDouble(qty.getText().toString());
            double p=Double.parseDouble(price.getText().toString());
            if(q<=0||p<=0||q>stock)throw new Exception();
            double amount=q*p; sales+=amount; stock-=q; save();
            total.setText(t("Bill total: ₹","மொத்தம்: ₹")+fmt(amount));
            Toast.makeText(this,t("Sale saved","விற்பனை சேமிக்கப்பட்டது"),0).show();
        }catch(Exception e){Toast.makeText(this,t("Check quantity, price and stock","அளவு, விலை, இருப்பைச் சரிபார்க்கவும்"),1).show();}});
        root.addView(calc);root.addView(back());
    }
    void showExpense(){
        base(t("Add Expense","செலவு சேர்க்க"));
        expense=new EditText(this);expense.setHint(t("Expense amount (₹)","செலவுத் தொகை (₹)"));
        expense.setInputType(8194);root.addView(expense);
        Button add=btn(t("Save Expense","செலவைச் சேமி"));
        add.setOnClickListener(v->{try{
            double x=Double.parseDouble(expense.getText().toString());if(x<=0)throw new Exception();
            expenses+=x;save();Toast.makeText(this,t("Expense saved","செலவு சேமிக்கப்பட்டது"),0).show();showHome();
        }catch(Exception e){Toast.makeText(this,t("Enter a valid amount","சரியான தொகையை உள்ளிடவும்"),1).show();}});
        root.addView(add);root.addView(back());
    }
    void showReport(){
        base(t("Daily Report","தினசரி அறிக்கை"));
        root.addView(text(t("Sales: ₹","விற்பனை: ₹")+fmt(sales),20));
        root.addView(text(t("Expenses: ₹","செலவுகள்: ₹")+fmt(expenses),20));
        root.addView(text(t("Net: ₹","நிகரத் தொகை: ₹")+fmt(sales-expenses),20));
        root.addView(back());
    }
}
