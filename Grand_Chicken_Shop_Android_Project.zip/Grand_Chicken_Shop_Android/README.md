# GRAND CHICKEN SHOP — Android prototype

Tamil/English offline-first starter app with a simple whole/cut chicken billing screen, local sales/expense totals, and estimated stock tracking.

## Build an APK
Open this folder in Android Studio, allow Gradle sync, then choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**.

You can also upload these files to the repository's `main` branch. The included GitHub Actions workflow will build a debug APK; download it from **Actions > Build Android APK > Artifacts** after the run succeeds.

## Important
This is an early prototype, not a production-ready point-of-sale system. It uses simple local preferences, has no secure staff login or role permissions, no supplier/customer ledger, no receipt printing, no tax-compliant invoice, no cloud sync, and no tested backup/restore. Stock starts at a demo value of 100 kg. Test thoroughly with sample transactions before real shop use.
