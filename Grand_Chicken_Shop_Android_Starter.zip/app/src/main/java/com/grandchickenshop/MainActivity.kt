package com.grandchickenshop

import android.app.Activity
import android.os.Bundle
import android.content.Context
import android.widget.*
import android.graphics.Typeface
import android.view.ViewGroup
import java.text.NumberFormat
import java.util.Locale

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("grand_shop_local", Context.MODE_PRIVATE) }
    private var language = "English"
    private var role = "Owner"
    private var sales = 0.0
    private var expenses = 0.0
    private var stockKg = 0.0
    private lateinit var root: LinearLayout
    private val inr = NumberFormat.getCurrencyInstance(Locale("en", "IN"))

    private fun t(en: String, ta: String) = if (language == "தமிழ்") ta else en

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        sales = prefs.getFloat("sales", 0f).toDouble()
        expenses = prefs.getFloat("expenses", 0f).toDouble()
        stockKg = prefs.getFloat("stock", 0f).toDouble()
        showHome()
    }

    private fun base(title: String) {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 24, 24, 24)
            setBackgroundColor(0xFFFFF8F3.toInt())
        }
        val heading = TextView(this).apply {
            text = "🐓 GRAND CHICKEN SHOP\\n$title"
            textSize = 23f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(0xFF7D1717.toInt())
            setPadding(0, 0, 0, 20)
        }
        root.addView(heading)
        setContentView(ScrollView(this).apply { addView(root) })
    }

    private fun button(label: String, action: () -> Unit) {
        root.addView(Button(this).apply { text = label; setOnClickListener { action() } })
    }

    private fun field(hint: String): EditText {
        val e = EditText(this).apply { this.hint = hint; textSize = 16f }
        root.addView(e)
        return e
    }

    private fun line(value: String, size: Float = 17f) {
        root.addView(TextView(this).apply {
            text = value; textSize = size; setPadding(0, 8, 0, 8)
            setTextColor(0xFF292929.toInt())
        })
    }

    private fun save() {
        prefs.edit().putFloat("sales", sales.toFloat())
            .putFloat("expenses", expenses.toFloat())
            .putFloat("stock", stockKg.toFloat()).apply()
    }

    private fun showHome() {
        base(t("Offline shop dashboard", "ஆஃப்லைன் கடை முகப்பு"))
        val langs = Spinner(this)
        langs.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item,
            listOf("English", "தமிழ்"))
        langs.setSelection(if (language == "தமிழ்") 1 else 0)
        langs.onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {}
            override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: android.view.View?, position: Int, id: Long) {
                language = if (position == 1) "தமிழ்" else "English"
            }
        }
        root.addView(langs)
        line("📍 Chennai Main Road, near Saravana Store, Vikravandi")
        line("☎ 9677990748")
        line("👤 " + t("Role", "பங்கு") + ": $role")
        line(t("Recorded sales: ", "பதிவு செய்யப்பட்ட விற்பனை: ") + inr.format(sales))
        line(t("Expenses: ", "செலவுகள்: ") + inr.format(expenses))
        line(t("Stock: ", "இருப்பு: ") + "$stockKg kg")
        button(t("New bill / புதிய பில்", "புதிய பில்")) { showBill() }
        button(t("Manage stock / இருப்பு", "இருப்பு நிர்வாகம்")) { showStock() }
        button(t("Add expense / செலவு", "செலவு சேர்க்க")) { showExpense() }
        button(t("Reports / அறிக்கைகள்", "அறிக்கைகள்")) { showReports() }
        button(t("Change role / பங்கு மாற்று", "பங்கு மாற்று")) { showRole() }
    }

    private fun showBill() {
        base(t("New chicken bill", "புதிய சிக்கன் பில்"))
        val type = Spinner(this)
        type.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item,
            listOf("Whole chicken", "Cut chicken"))
        root.addView(type)
        val kg = field(t("Weight in kg", "எடை கிலோ"))
        val rate = field(t("Price per kg (₹)", "ஒரு கிலோ விலை (₹)"))
        button(t("Save sale", "விற்பனையை சேமி")) {
            val weight = kg.text.toString().toDoubleOrNull()
            val price = rate.text.toString().toDoubleOrNull()
            if (weight == null || price == null || weight <= 0 || price <= 0) {
                Toast.makeText(this, t("Enter valid weight and price", "சரியான எடை மற்றும் விலையை உள்ளிடவும்"), Toast.LENGTH_LONG).show()
            } else if (weight > stockKg && stockKg > 0) {
                Toast.makeText(this, "Stock warning: available $stockKg kg", Toast.LENGTH_LONG).show()
            } else {
                sales += weight * price
                if (stockKg > 0) stockKg = (stockKg - weight).coerceAtLeast(0.0)
                save()
                Toast.makeText(this, t("Sale saved on this device", "விற்பனை சேமிக்கப்பட்டது"), Toast.LENGTH_LONG).show()
                showHome()
            }
        }
        button(t("Back", "பின் செல்ல")) { showHome() }
    }

    private fun showStock() {
        base(t("Stock management", "இருப்பு நிர்வாகம்"))
        line(t("Current stock: ", "தற்போதைய இருப்பு: ") + "$stockKg kg")
        val add = field(t("Add stock in kg", "சேர்க்க வேண்டிய கிலோ"))
        button(t("Update stock", "இருப்பை புதுப்பி")) {
            val amount = add.text.toString().toDoubleOrNull()
            if (amount == null || amount < 0) Toast.makeText(this, "Enter a valid amount", Toast.LENGTH_SHORT).show()
            else { stockKg += amount; save(); showHome() }
        }
        button(t("Back", "பின் செல்ல")) { showHome() }
    }

    private fun showExpense() {
        base(t("Add expense", "செலவு சேர்க்க"))
        val amount = field(t("Expense amount (₹)", "செலவு தொகை (₹)"))
        button(t("Save expense", "செலவை சேமி")) {
            val v = amount.text.toString().toDoubleOrNull()
            if (v == null || v <= 0) Toast.makeText(this, "Enter a valid amount", Toast.LENGTH_SHORT).show()
            else { expenses += v; save(); showHome() }
        }
        button(t("Back", "பின் செல்ல")) { showHome() }
    }

    private fun showReports() {
        base(t("Sales report", "விற்பனை அறிக்கை"))
        line(t("Total sales: ", "மொத்த விற்பனை: ") + inr.format(sales))
        line(t("Expenses: ", "செலவுகள்: ") + inr.format(expenses))
        line(t("Sales minus expenses (not net profit): ", "விற்பனை கழித்த செலவுகள் (நிகர லாபம் அல்ல): ") + inr.format(sales - expenses))
        button(t("Back", "பின் செல்ல")) { showHome() }
    }

    private fun showRole() {
        base(t("Choose demo role", "பங்கு தேர்வு"))
        listOf("Owner", "Billing Staff", "Delivery").forEach { r ->
            button(r) { role = r; showHome() }
        }
    }
}
